from aiogram import Dispatcher

from loader import dp
from .throttling import ThrottlingMiddleware
from .is_admin import AdminFilter


if __name__ == "middlewares":
    dp.middleware.setup(ThrottlingMiddleware())
    dp.filters_factory.bind(AdminFilter)
