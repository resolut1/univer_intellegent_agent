from aiogram.dispatcher.filters import BoundFilter
from aiogram import Bot, Dispatcher, types

from data import config


class AdminFilter(BoundFilter):
    key = 'is_admin'
    
    def __init__(self, is_admin):
        self.is_admin = is_admin
    
    
    async def check(self, message: types.Message):
        return str(message.from_user.id) == config.ADMIN