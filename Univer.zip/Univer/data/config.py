BOT_TOKEN = "................."
ADMIN = "......"
IP = "localhost"