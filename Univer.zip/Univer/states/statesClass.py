from aiogram.dispatcher.filters.state import StatesGroup, State

class GetStudentData(StatesGroup):
    full_name = State()
    group_info = State()
    

class GetEducatorData(StatesGroup):
    full_name = State()
    contact_info = State()
    

class GetRoomData(StatesGroup):
    title = State()
    
    
class ChangeFullName(StatesGroup):
    full_name = State()


class ChangeContactInfo(StatesGroup):
    contact_info = State()
    

class ConfirmDeleteAccount(StatesGroup):
    confirm = State()
    
    
class ChangeGroupInfo(StatesGroup):
    group_info = State()
    
    
class ChangeRoomTitle(StatesGroup):
    new_title = State()


class ConfirmDeleteRoom(StatesGroup):
    confirm = State()
    
class DeleteMembersRoom(StatesGroup):
    user_id = State()
    
class NewPinnedMessage(StatesGroup):
    message = State()
    
class LeavingTheRoom(StatesGroup):
    room_id = State()