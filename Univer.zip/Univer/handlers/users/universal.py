import json

from aiogram import types
from aiogram.types import CallbackQuery
from aiogram.utils.deep_linking import get_start_link

from loader import db, bot, dp, bold
from states.statesClass import *
from utils.db_api.dbClass import UserData, RoomData


async def delete_messages(n: int, message_chat_id: int, start_message_id: int) -> None:
    for i in range(n):
        try:
            await bot.delete_message(message_chat_id, start_message_id-i)
        except Exception as _ex:
            print(_ex)


@dp.callback_query_handler(lambda c: c.data == "getInviteLinkEducator", is_admin=True) # для Админа
async def getInviteLinkEducator(call: CallbackQuery):
    code = f"educators_{call.from_user.id}"
    link = await get_start_link(code, encode=True)
    await call.message.answer(text=f'🫂 Теперь отравьте эту ссылку преподавателю или даже целой группе преподавателей\n\n{bold("Ссылка:")} {link}')
    await bot.answer_callback_query(call.id)


async def add_user_to_room(argument:str, user: UserData, new_reg: bool):
    argument_list = argument.split('_')
    key_n = int(argument_list[1])
    try:
        room_info = db.select_room('key_n', key_n)
        members = room_info.members
        if not any(u["user_id"] == user.user_id for u in members):
            members.append({
                'user_id': user.user_id,
                'full_name': user.full_name
            })
            db.update_value('rooms', 'members', json.dumps(members), 'key_n', key_n)
            if new_reg is False:
                user = db.search_and_check_users(user.user_id)
                new_room_list = user.rooms
                new_room_list.append(key_n)
                db.update_value('students', 'rooms', json.dumps(new_room_list), 'user_id', user.user_id)
            return True
        else:
            return False
    except Exception as _ex:
        print(_ex)
    
    
async def check_and_add_to_room(message: types.Message, argument: str, user: UserData, new_reg: bool):
    result = await add_user_to_room(argument, user, new_reg)
    if result is True:
        await message.answer("Вы успешно добавлены в группу")
    else: await message.answer('Вы уже участник или группы больше не существует')