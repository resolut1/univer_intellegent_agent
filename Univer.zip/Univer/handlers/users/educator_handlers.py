import json
from typing import List, Tuple, Dict

from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from aiogram.utils.deep_linking import get_start_link

from keyboards.inline import dict_keyboards
from keyboards.inline.inline_key_generator import inline_key_gen
from handlers.users.universal import delete_messages
from loader import dp, bot, db, mono, bold
from utils.db_api.dbClass import RoomData
from states.statesClass import *
import aiofiles


async def regEducator(message: types.Message):
    async with aiofiles.open("images/educators.png", mode='rb') as photo_file:
            await bot.send_photo(message.chat.id, photo=photo_file, caption=f'🪬 {bold("[Форма регистрации]")}\n\nВы перешли по верифицированной ссылке и будете зарегистрированы в качестве <b>«Преподавателя»</b> без каких-либо проверок.\n\n{bold("Введите ваше ФИО:")}',
                                 reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await GetEducatorData.full_name.set()


async def get_invite_room_link(key_n: int, user_id: int):
    code = f"invite_{key_n}_{user_id}"
    link = await get_start_link(code, encode=True)
    return link


@dp.message_handler(state=GetEducatorData.full_name)
async def GetEducatorDataFullName(message: types.Message, state: FSMContext):
    await state.update_data(full_name=message.text)
    await message.answer(f'☎️ {bold("[Контактная информация]")}\nУкажите способ связи, например: (telegram - @user | +7(990)-000-00-00):',
                         reply_markup=await inline_key_gen(dict_keyboards.back_button_skip_contact))
    await GetEducatorData.contact_info.set()


@dp.message_handler(state=GetEducatorData.contact_info)
async def GetEducatorDataContactInfo(message: types.Message, state: FSMContext):
    await state.update_data(contact_info=message.text)
    data = await state.get_data()
    full_name = data.get('full_name')
    contact_info = data.get('contact_info')
    db.add_user('educators', [message.from_user.id, full_name, contact_info, '[]'])
    
    async with aiofiles.open("images/user.png", mode='rb') as photo_file:
            await bot.send_photo(message.chat.id, photo=photo_file, caption=f'❇️ {bold("Успешная регистрация!")}\n\nВаши данные:\n{bold("ID:")} {mono(message.from_user.id)}\n{bold("ФИО:")} {mono(full_name)}\n{bold("Контактная информация:")} {mono(contact_info)}',
                                 reply_markup=await inline_key_gen(dict_keyboards.educator_menu))
    
    await state.finish()
    await delete_messages(4, message.chat.id, message.message_id)
    

@dp.callback_query_handler(lambda c: c.data == "createNewRoom")
async def createNewRoom_callback(call: CallbackQuery):
    async with aiofiles.open("images/newroom.png", mode='rb') as photo_file:
            await bot.send_photo(call.message.chat.id, photo=photo_file, caption=f'🏛 {bold("[Создание новой комнаты]")}\n\nУкажите название команты:',
                                 reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await GetRoomData.title.set()
    await bot.answer_callback_query(call.id)
    

@dp.message_handler(state=GetRoomData.title)
async def GetRoomTitle(message: types.Message, state: FSMContext):
    room = db.add_rooms([message.from_user.id, message.text, '[]', '[]'])
    user = db.search_and_check_users(message.from_user.id)
    new_rooms_list = user.rooms
    new_rooms_list.append(room.key_n)
    db.update_value('educators', 'rooms', json.dumps(new_rooms_list), 'user_id', message.from_user.id)
    await delete_messages(2, message.chat.id, message.message_id)
    link = await get_invite_room_link(room.key_n, message.from_user.id)
    text = f'''❇️ {bold("Комната успешно создана!")}
    
{bold("ID комнаты:")} {mono(room.key_n)}
{bold("Название:")} {mono(room.title)}

{bold("Пригласительная ссылка: ")}\n{link}'''

    async with aiofiles.open("images/room.png", mode='rb') as photo_file:
            await bot.send_photo(message.chat.id, photo=photo_file, caption=text,
                                 reply_markup=await inline_key_gen(dict_keyboards.get_room_control_menu(room.key_n)))
            
    await state.finish()


@dp.callback_query_handler(lambda c: c.data == "skipContactInfo", state=GetEducatorData.contact_info)
async def skip_contact_info(call: CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(call.id)
    data = await state.get_data()
    full_name = data.get('full_name')
    db.add_user('educators', [call.from_user.id, full_name, 'Пусто', '[]'])
    
    async with aiofiles.open("images/user.png", mode='rb') as photo_file:
            await bot.send_photo(call.message.chat.id, photo=photo_file, caption=f'❇️ {bold("[Успешная регистрация]")}\nВаши данные:\n{bold("ID:")} {mono(call.from_user.id)}\n{bold("ФИО:")} {mono(full_name)}\n{mono("Контактная информация:")} Пусто',
                                 reply_markup=await inline_key_gen(dict_keyboards.educator_menu))
    
    await state.finish()
    await delete_messages(3, call.message.chat.id, call.message.message_id)
    

@dp.callback_query_handler(lambda c: c.data == "getInviteStudentLink")
async def getInviteStudentLink(call: CallbackQuery):
    code = f"students_{call.from_user.id}"
    link = await get_start_link(code, encode=True)
    await call.message.answer(text=f'🫂 Теперь отравьте эту ссылку студенту или даже целой группе студентов\n\n{bold("Ссылка: ")}{link}',
                              reply_markup= await inline_key_gen(dict_keyboards.educator_menu))
    await bot.answer_callback_query(call.id)


@dp.callback_query_handler(lambda c: c.data == "editAccount")
async def editAccount(call: CallbackQuery):
    user = db.search_and_check_users(call.from_user.id)
    count_group = len(user.rooms)
    base_text = f'''📝 {bold("[Меню редактирования аккаунта]")}:
    
{bold("ID:")} {mono(user.user_id)}
{bold("ФИО:")} {mono(user.full_name)}'''
    

    if user.role == 'educators':
        extra_text = f'''\n{bold("Контактная информация:")} {user.information}
Число курируемых групп: {bold(count_group)}'''
        reply_markup = await inline_key_gen(dict_keyboards.get_control_menu('educators'))
    elif user.role == 'students':
        extra_text = f'''\n{bold("Группа:")} {mono(user.information)}
Вы участвуете в: {bold(count_group)} группах'''
        reply_markup = await inline_key_gen(dict_keyboards.get_control_menu('students'))

    full_text = base_text + extra_text
    await call.message.answer(full_text, reply_markup=reply_markup)
    await bot.answer_callback_query(call.id)

        
@dp.callback_query_handler(lambda c: c.data == "changeFullName")
async def changeFullName(call: CallbackQuery):
    await call.message.answer(f'🪬 {bold("[Форма редактирования]")}:\n\nВведите ваше ФИО:',
                         reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await ChangeFullName.full_name.set()
    await bot.answer_callback_query(call.id)
    
    
@dp.message_handler(state=ChangeFullName.full_name)
async def ChangeFullNameState(message: types.Message, state: FSMContext):
    user = db.search_and_check_users(message.from_user.id)
    db.update_value(user.role, 'full_name', message.text, 'user_id', message.from_user.id)
    keyboard = dict_keyboards.student_menu if user.role == "students" else dict_keyboards.educator_menu
    await delete_messages(4, message.chat.id, message.message_id)
    await message.answer(f'📮 {bold("[ИНФО]")} Данные о ФИО успешно изменены.',
                         reply_markup=await inline_key_gen(keyboard))
    await state.finish()
    

@dp.callback_query_handler(lambda c: c.data == "fillContactInfo")
async def fillContactInfo(call: CallbackQuery):
    await call.message.answer(f'🪬 {bold("[Форма редактирования]")}\n\nУкажите контактную информацию:',
                         reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await ChangeContactInfo.contact_info.set()
    await bot.answer_callback_query(call.id)
    
    
@dp.message_handler(state=ChangeContactInfo.contact_info)
async def fillContactInfoState(message: types.Message, state: FSMContext):
    db.update_value('educators', 'information', message.text, 'user_id', message.from_user.id)
    await delete_messages(4, message.chat.id, message.message_id)
    await message.answer(f'📮 {bold("[ИНФО]")} Данные о контактной информации успешно изменены.',
                         reply_markup=await inline_key_gen(dict_keyboards.educator_menu))
    await state.finish()


@dp.callback_query_handler(lambda c: c.data == "deleteAccount")
async def deleteAccount(call: CallbackQuery):
    await call.message.answer(f'🪬 {bold("[Форма удаления]")}\n\nВы действительно хотите удалить аккаунт? Тогда напишите "{mono("YES")}":',
                         reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await ConfirmDeleteAccount.confirm.set()
    await bot.answer_callback_query(call.id)
    
    
@dp.message_handler(state=ConfirmDeleteAccount.confirm)
async def deleteAccountState(message: types.Message, state: FSMContext):
    if message.text.strip() in ['yes', 'YES']:
        db.delete_record('educators', 'user_id', message.from_user.id)
        db.delete_record('students', 'user_id', message.from_user.id)
        await message.answer('Аккаунт удален')
    else:
        await message.answer(f'📮 {bold("[ИНФО]")} Я не получил подтверждения, аккаунт {bold("не был удален!")}')
    await state.finish()


def get_members(key_n: int):
    text = f'👤 {bold("[Список пользователей]")}\nВставьте {bold("user_id")} студента, которого хотите удалить.\n\n'
    room = db.select_room('key_n', key_n)
    if len(room.members) == 0: text = f'📮 {bold("[ИНФО]")}\nКомната пока пустая, но я уверен, что это ненадолго!'
    else:
        for user in room.members:
            text+= f'{bold("user_id:")} {user["user_id"]}\n{bold("ФИО:")} {user["full_name"]}\n --------------------------\n\n'
        
    return text
        

@dp.callback_query_handler(lambda c: c.data == "listRoomsEducator")
async def listRoomsEducator(call: CallbackQuery):
    buttons = dict_keyboards.get_my_room_list(call.from_user.id)
    if len(buttons) == 0:
        await bot.answer_callback_query(call.id, text='👀 Ваш список комнат пуст.\n\n💡 нажмите на пустое место чтобы закрыть!', show_alert=True)
    else:
        await call.message.answer(f'🛄 {bold("[Меню курируемых комнат]")}\nВот полный список ваших комнат:',
                            reply_markup=await inline_key_gen(buttons))
        
    await bot.answer_callback_query(call.id)


@dp.callback_query_handler(dict_keyboards.cb_room_control.filter())
async def room_control_handler(call: CallbackQuery, callback_data: dict, state: FSMContext):
    await bot.answer_callback_query(call.id)
    key_room = callback_data['key_n']
    room = db.select_room('key_n', key_room)
    if room is not None:
        await state.update_data(key_n=key_room)
        match callback_data['flag']:
            
            case 'inviteStudentRoom':
                link = await get_invite_room_link(callback_data['key_n'], call.from_user.id)
                await call.message.answer(f'📮 {bold("[ИНФО]")}\nТеперь отравьте эту ссылку студенту или даже целой группе студентов\n\n{bold("Ссылка: ")}{link}',
                                        reply_markup=await inline_key_gen(dict_keyboards.get_room_control_menu(key_room)))
            
            case 'editRoom':
                await call.message.answer(f'🏛 {bold("[Меню управления комнатой]:")}',
                                        reply_markup=await inline_key_gen(dict_keyboards.get_room_management(key_room)))
            
            case 'backToRoomControlMenu':
                await delete_messages(1, call.message.chat.id, call.message.message_id)

            case 'messageRoomMenu':
                await call.message.answer(f'🏛 {bold("[Меню управления сообщениями комнаты]:")}',
                                        reply_markup=await inline_key_gen(dict_keyboards.get_room_message_management(key_room)))
                
            case 'changeTitle':
                await call.message.answer(f'🏷 {bold("[Редактирование названия комнаты]")}\n\nВведите новое название комнаты:',
                                        reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
                await ChangeRoomTitle.new_title.set()
                await state.update_data(key_n=key_room)
                
            case 'deleteRoom':
                await call.message.answer(f'🪬 {bold("[Форма удаления]")}\n\nВы действительно хотите удалить комнату? Тогда напишите "{mono("YES")}":',
                            reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
                await ConfirmDeleteRoom.confirm.set()
                await state.update_data(key_n=key_room)
                
            case 'deleteMembers':
                text = get_members(key_room)    
                if '[Список пользователей]' in text:
                    await call.message.answer(text, reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
                    await DeleteMembersRoom.user_id.set()
                else:
                    await bot.answer_callback_query(call.id, text='👀 В этой комнате нет участников.\n\n💡 нажмите на пустое место чтобы закрыть!', show_alert=True)
            
            case 'clearPinnedMessages':
                db.update_value('rooms', 'pinned_messages', '[]', 'key_n', key_room)
                await call.message.answer(f'📮 {bold("[ИНФО]")} Список закрепленных сообщений был очишен!')
            
            case 'pinnedNewMessage':
                await call.message.answer(f'📩 {bold("[Создать сообщение]")}\nВведите текст, который увидят все участники данной комнаты:', reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
                await NewPinnedMessage.message.set()
                
            case _:
                async with aiofiles.open("images/room.png", mode='rb') as photo_file:
                    await bot.send_photo(call.message.chat.id, photo=photo_file, caption=f'🏛 {bold("[Меню комнаты]")}: {callback_data["flag"]}',
                                reply_markup=await inline_key_gen(dict_keyboards.get_room_control_menu(callback_data['key_n'])))
                
    else:
        await call.message.answer(f'📮 {bold("[ИНФО]")}\nКомната была удалена!')


def remove_user_by_id(user_id: int, members_list: List) -> List[Dict[int, str]]:
    index_to_delete = next((i for i, user in enumerate(members_list) if user['user_id'] == user_id), None)
    if index_to_delete is not None:
        del members_list[index_to_delete]
    
    return members_list


def get_all_user_id_members(list_members: List[Dict[str, str]]):
    user_id_list = list()
    for user in list_members:
        user_id_list.append(user['user_id'])
    
    return user_id_list


async def mailing_pinned_message(room: RoomData, user_id_list: List[int], pin_message: str):
    for user_id in user_id_list:
        try:
            await bot.send_message(user_id, f'📮 {bold("[ИНФО]")} Было закрепено новое сообщение из комнаты:{bold(room.title)}\n\nСообщение: {pin_message}')
        except Exception as _ex:
            print(_ex)
            
            
@dp.message_handler(state=NewPinnedMessage.message)
async def NewPinnedMessageState(message: types.Message, state: FSMContext):
    data = await state.get_data()
    key_n = data.get('key_n')
    try:
        room = db.select_room('key_n', key_n)
        old_messages = room.pinned_messages
        old_messages.append(message.text)
        db.update_value('rooms', 'pinned_messages', json.dumps(old_messages), 'key_n', key_n)
        user_id_list = get_all_user_id_members(room.members)
        await mailing_pinned_message(room, user_id_list, message.text)
        await message.answer(f'📮 {bold("[ИНФО]")} Новое сообщение было закреплено и разослано участникам!')
    except Exception as _ex:
        print(_ex)
    await state.finish()


@dp.message_handler(state=DeleteMembersRoom.user_id)
async def DeleteMembersRoomState(message: types.Message, state: FSMContext):
    data = await state.get_data()
    input_user_id = int(message.text.strip())
    key_n = data.get('key_n')
    try:
        room = db.select_room('key_n', key_n)
        new_members = remove_user_by_id(input_user_id, room.members)
        db.update_value('rooms', 'members', json.dumps(new_members), 'key_n', key_n)
        user = db.search_and_check_users(input_user_id)
        new_room_list = [x for x in user.rooms if x != int(key_n)]
        db.update_value('students', 'rooms', json.dumps(new_room_list), 'user_id', input_user_id)
        await message.answer(f'📮 {bold("[ИНФО]")} Пользователь был удален из комнаты: {bold(room.title)}',
                             reply_markup=await inline_key_gen(dict_keyboards.get_room_control_menu(key_n)))
    except Exception as _ex:
        print(_ex)
    await state.finish()


@dp.message_handler(state=ConfirmDeleteRoom.confirm)
async def ConfirmDeleteRoomState(message: types.Message, state: FSMContext):
    await delete_messages(4, message.chat.id, message.message_id)
    if message.text.strip() == 'yes': 
        data = await state.get_data()
        key_n = data.get('key_n')
        db.delete_record('rooms', 'key_n', key_n)
        try:
            user = db.search_and_check_users(message.from_user.id)
            new_room_list = [x for x in user.rooms if x != int(key_n)]
            db.update_value('educators', 'rooms', json.dumps(new_room_list), 'user_id', message.from_user.id)
            db.deleting_room_from_all_users(key_n=key_n)
        except Exception as _ex: print(_ex)
        await message.answer(f'📮 {bold("[ИНФО]")} Комната успешно удалена!')
    else:
        await message.answer(f'📮 {bold("[ИНФО]")} Я не получил подтверждения, комната {bold("не была удален!")}')
    await state.finish()


@dp.message_handler(state=ChangeRoomTitle.new_title)
async def ChangeRoomTitleState(message: types.Message, state: FSMContext):
    data = await state.get_data()
    key_n = data.get('key_n')
    db.update_value('rooms', 'title', message.text, 'key_n', key_n)
    await delete_messages(3, message.chat.id, message.message_id)
    await message.answer(f'📮 {bold("[ИНФО]")} Название комнаты успешно изменено на: {bold(message.text)}',
                        reply_markup=await inline_key_gen(dict_keyboards.get_room_control_menu(key_n)))
    await state.finish()