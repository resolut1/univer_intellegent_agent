from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import Command, CommandStart
from aiogram.utils.deep_linking import decode_payload, get_start_link

from handlers.users.educator_handlers import regEducator
from handlers.users.student_handlers import regStudent
from handlers.users.universal import check_and_add_to_room
from keyboards.inline import dict_keyboards
from keyboards.inline.inline_key_generator import inline_key_gen
from loader import dp, db, bot
import aiofiles


# Функция генерации ссылок для упрощения кода УДАЛИТЬ потом
async def generate_ref_links(user_id: int) -> str:
    links = [
        await get_start_link(f"students_{user_id}", encode=True),
        await get_start_link(f"educators_{user_id}", encode=True),
        await get_start_link(f"invite_1_{user_id}", encode=True)
    ]
    labels = ['student', 'educator', 'invite']
    return '\n\n\n'.join(f'{label}\n{link}' for label, link in zip(labels, links))


@dp.message_handler(Command('ref'))
async def ref(message: types.Message):
    links_message = await generate_ref_links(message.from_user.id)
    await message.answer(links_message)


def check_type_argument(args: str) -> str | None:
    return args.split('_')[0] if args else None


@dp.message_handler(CommandStart(), is_admin=True)
async def bot_start_admin(message: types.Message, state: FSMContext):
    await message.answer(f'🛄 <b>Добро пожаловать, {message.from_user.first_name}!</b>\nВот меню администратора:',
                         reply_markup=await inline_key_gen(dict_keyboards.admin_menu_keyboard))


@dp.message_handler(CommandStart())
async def bot_start(message: types.Message, state: FSMContext):
    ref_link = message.get_args()
    argument = decode_payload(ref_link) if ref_link else ""
    user = db.search_and_check_users(user_id=message.from_user.id)
    type_arg = check_type_argument(argument)

    if not argument and user is None:  # нет аргументов и пользователь не зарегистрирован
        async with aiofiles.open("images/students.png", mode='rb') as photo_file:
            await bot.send_photo(message.chat.id, photo=photo_file, caption=f'🛄 <b>Добро пожаловать, {message.from_user.first_name}!</b>\nЯ не нашел вас в базе данных. Пожалуйста, пройдите короткую регистрацию по кнопке ниже или получите пригласительную ссылку от преподавателя.',
                                 reply_markup=await inline_key_gen(dict_keyboards.register_keyboard))
        return

    # Обработка уже зарегистрированных пользователей
    if user:
        if user.role == 'students' and type_arg == 'invite':
            await check_and_add_to_room(message, argument, user, new_reg=False)
        menu = dict_keyboards.student_menu if user.role == 'students' else dict_keyboards.educator_menu
        async with aiofiles.open("images/user.png", mode='rb') as photo_file:
            await bot.send_photo(message.chat.id, photo=photo_file, caption=f'🛄 <b>{message.from_user.first_name}, вы в главном меню\nВыберите интересующий вас пункт:</b>',
                                reply_markup=await inline_key_gen(menu))
        
    else:
        # Обработка приглашений для новых пользователей
        if type_arg in ["students", "educators", "invite"]:
            if type_arg in ["students", "invite"]:
                await regStudent(message,'verify_link' if type_arg != "invite" else "no_link", argument, state)
            if type_arg == "educators":
                await regEducator(message)