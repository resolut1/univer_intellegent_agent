import json

from aiogram import types
from aiogram.types import CallbackQuery
from aiogram.dispatcher import FSMContext
from aiogram.utils.deep_linking import get_start_link

from handlers.users.universal import check_and_add_to_room, delete_messages
from keyboards.inline import dict_keyboards
from keyboards.inline.inline_key_generator import inline_key_gen
from loader import dp, bot, db, mono, bold
from states.statesClass import *
from utils.db_api.dbClass import UserData
import aiofiles


def check_type_argument(args: str) -> str | None:
    return args.split('_')[0] if args else None


@dp.message_handler(commands=['clear'])
async def clear_table(message: types.Message):
    db.clear_table()


@dp.callback_query_handler(lambda c: c.data == "getInviteLinkStudent")
async def getInviteLinkStudent(call: CallbackQuery):
    code = f"students_{call.from_user.id}"
    link = await get_start_link(code, encode=True)
    await call.message.answer(text=f'🫂 Теперь отравьте эту ссылку студенту или даже целой группе\n\n{bold("Ссылка:")} {link}')
    await bot.answer_callback_query(call.id)


@dp.callback_query_handler(lambda c: c.data == "regStudent")
async def regStudent_callback(call: CallbackQuery):
    await bot.answer_callback_query(call.id)
    await regStudent(call, 'no_link', None, None)


async def regStudent(call: CallbackQuery, type: str, argument: str, state: FSMContext): # no_link  || verify_link || invite_link
    type_arg = check_type_argument(argument)
    if argument is not None:
        await state.update_data(invite_info=argument)
    if type == "verify_link": reg_text = f'🪬 {bold("[Форма регистрации]")}\n\nВы перешли по верифицированной ссылке и будете зарегистрированы в качестве <b>«Студента»</b> без каких-либо проверок.\n\n{bold("Введите ваше ФИО:")}'
    if type == "no_link": reg_text = f'🪬 {bold("[Форма регистрации]")}\n\nВы перешли не по ссылке-приглашению, возможно понадобится одобрение преподавателя.\n\n{bold("Введите ваше ФИО:")}'
    if type_arg == "invite": reg_text = f'🪬 {bold("[Форма регистрации]")}\n\nВы перешли по ссылке-приглашению и после регистрации, сразу будете добавлены в комнату.\n\n{bold("Введите ваше ФИО:")}'
    try:
        await call.message.answer(reg_text, reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    except Exception as _ex:
        async with aiofiles.open("images/students.png", mode='rb') as photo_file:
            await bot.send_photo(call.chat.id, photo=photo_file, caption=reg_text,
                                 reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
        
        #await call.answer(reg_text, reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await GetStudentData.full_name.set()
    

@dp.message_handler(state=GetStudentData.full_name)
async def GetStudentDataFullName(message: types.Message, state: FSMContext):
    await state.update_data(full_name=message.text)
      
    await message.answer(f'📝 {bold("[Ифнормация о группе]")}\n\nУкажите её в формате:\n({mono("31ИВТ - 3 Курс")}):',
                         reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await GetStudentData.group_info.set()
        
    
@dp.message_handler(state=GetStudentData.group_info)
async def GetStudentDataGroupInfo(message: types.Message, state: FSMContext):
    await state.update_data(group_info=message.text)
    data = await state.get_data()
    full_name = data.get('full_name')
    group_info = data.get('group_info')
    rooms = []
    
    async with aiofiles.open("images/user.png", mode='rb') as photo_file:
            await bot.send_photo(message.chat.id, photo=photo_file, caption=f'❇️ {bold("Успешная регистрация!")}\n\nВаши данные:\n{bold("ID:")} {mono(message.from_user.id)}\n{bold("ФИО:")} {mono(full_name)}\n{bold("Группа:")} {mono(group_info)}',
                                reply_markup=await inline_key_gen(dict_keyboards.student_menu))
    
    try:
        argument = data.get('invite_info')
        if str(argument).startswith('invite'):
            key_n = int(str(argument).split('_')[1])
            rooms.append(key_n)
            await check_and_add_to_room(message, argument, UserData(
                key_n=0,
                user_id=message.from_user.id, 
                full_name=full_name, 
                information=group_info, 
                rooms=rooms, 
                role='students'), new_reg=True)
    except Exception as _ex:
        print(_ex)
    db.add_user('students', [message.from_user.id, full_name, group_info, json.dumps(rooms)])
    await state.finish()
    

@dp.callback_query_handler(lambda c: c.data == "backToMainMenu", state=[GetStudentData, GetEducatorData, GetRoomData, ConfirmDeleteAccount, ChangeFullName, ChangeContactInfo, ChangeGroupInfo, ChangeRoomTitle, ConfirmDeleteRoom, NewPinnedMessage, DeleteMembersRoom, LeavingTheRoom, NewPinnedMessage])
async def back_button_main_menu(call: CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(call.id)
    current_state = await state.get_state()
    await call.message.delete()
    if current_state in ['GetEducatorData:contact_info', 'GetStudentData:group_info']:
        await delete_messages(2, call.message.chat.id, call.message.message_id - 1)
        await call.message.answer(f'📮 {bold("[ИНФО]")} Регистрация была отменена!')
    
    if current_state in ['ChangeRoomTitle:new_title', 'ConfirmDeleteRoom:confirm', 'NewPinnedMessage:message, DeleteMembersRoom:user_id, LeavingTheRoom:room_id']:
        await delete_messages(1, call.message.chat.id, call.message.message_id)
        await call.message.answer(f'📮 {bold("[ИНФО]")} Действие отменено')
        
    await state.finish()
    

@dp.callback_query_handler(lambda c: c.data == "viewLastFixedMessage")
async def viewLastFixedMessage(call: CallbackQuery):
    text = f"☎️ {bold('[Все закрепленные сообщения]')}\nОтсортированы по комнатам в которых вы учавствуете\n\n"
    try:
        user = db.search_and_check_users(call.from_user.id)
        if len(user.rooms) == 0:
            await bot.answer_callback_query(call.id, text='👀 Вы не состоите ни в одной из комнат.\n\n💡 нажмите на пустое место чтобы закрыть!', show_alert=True)
        else:
            for room_id in user.rooms:
                room = db.select_room('key_n', room_id)
                text2 = f"_________________________\n\n🏛 Комната: {bold(room.title)}\n"
                for pin_message in room.pinned_messages:
                    text2+= f'• {pin_message}\n'
                text+=text2
            text+='_________________________\n'
            if '•' not in text:
                await bot.answer_callback_query(call.id, text='👀 Закрепленных сообщений пока что нет.\n\n💡 нажмите на пустое место чтобы закрыть!', show_alert=True)
            else:
                await call.message.answer(text)
                
    except Exception as _ex:
        print(_ex)
    await bot.answer_callback_query(call.id)


@dp.callback_query_handler(lambda c: c.data == "exitRoomsStudent")
async def exitRoomsStudent(call: CallbackQuery):
    text = f"☎️ {bold('[Список ваших комнат]')}\nНапишите ID комнаты из которой хотите выйти:\n\n"
    try:
        user = db.search_and_check_users(call.from_user.id)
        if len(user.rooms) == 0:
            await bot.answer_callback_query(call.id, text='👀 Вы не состоите ни в одной из комнат.\n\n💡 нажмите на пустое место чтобы закрыть!', show_alert=True)
        else:
            for room_id in user.rooms:
                room = db.select_room('key_n', room_id)
                text+= f"🆔: {mono(room.key_n)} | 🏛 {bold('Комната:')} {mono(room.title)}\n\n\n"
            
            await call.message.answer(text, reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
            await LeavingTheRoom.room_id.set() 
                
    except Exception as _ex:
        print(_ex)
    await bot.answer_callback_query(call.id)


@dp.message_handler(state=LeavingTheRoom.room_id)
async def LeavingTheRoomState(message: types.Message, state: FSMContext):
    try:
        room = db.select_room('key_n', int(message.text))
        members_this_room = room.members
        new_members = [user for user in members_this_room if user["user_id"] != message.from_user.id]
        if members_this_room == new_members: await message.answer('Вы не являетесь ее участником')
        else:
            db.update_value('rooms', 'members', json.dumps(new_members), 'key_n', int(message.text))
            user = db.search_and_check_users(message.from_user.id)
            ar = user.rooms
            ar.remove(int(message.text))
            db.update_value('students', 'rooms', json.dumps(ar), 'user_id', message.from_user.id)
        await delete_messages(2, message.chat.id, message.message_id)
    except:
        await message.answer('Такой комнаты не существует или вы не являетесь ее участником')
    await state.finish()


@dp.callback_query_handler(lambda c: c.data == "contactInformEducators")
async def contactInformEducators(call: CallbackQuery):
    text = f"☎️ {bold('[Справочная информация]')}\n\n"
    educators = db.get_all_contact_info_educator()
    for educator in educators:
        text+= f"{bold('ФИО: ')}{mono(educator[2])}\n{bold('Контакт: ')}{mono(educator[3])}\n_________________\n\n"
    
    await call.message.answer(text)
    await bot.answer_callback_query(call.id)


@dp.callback_query_handler(lambda c: c.data == "changeGroup")
async def changeGroup(call: CallbackQuery):
    await call.message.answer(f'🪬 {bold("[Форма редактирования]:")}\n\nВведите новую информацию о группе:',
                         reply_markup=await inline_key_gen([dict_keyboards.back_button_main_menu]))
    await ChangeGroupInfo.group_info.set()
    await bot.answer_callback_query(call.id)


@dp.callback_query_handler(lambda c: c.data in ["backToMainStudentMenu", "backToMainEduMenu"])
async def back(call: CallbackQuery):
    await bot.delete_message(call.message.chat.id, call.message.message_id)
    await bot.answer_callback_query(call.id)

    
@dp.message_handler(state=ChangeGroupInfo.group_info)
async def changeGroupState(message: types.Message, state: FSMContext):
    db.update_value('students', 'information', message.text, 'user_id', message.from_user.id)
    await delete_messages(4, message.chat.id, message.message_id)
    await message.answer(f'📮 {bold("[ИНФО]")} Данные о группе успешно изменены.',
                         reply_markup=await inline_key_gen(dict_keyboards.student_menu))
    await state.finish()