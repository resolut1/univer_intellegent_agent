import json
import sqlite3
from dataclasses import dataclass
from typing import List, Any, Dict

from path_list import db_path


@dataclass
class RoomData:
    key_n: int
    admin_id: int
    title: str
    pinned_messages: List[str]
    members: List[int]
    

@dataclass
class UserData:
    key_n: int
    user_id: int
    full_name: str
    information: str
    rooms: List[int]
    role: str
    

class Database(object):
    DB_LOCATION = db_path + ".db"
    
    def __init__(self):
        self.connection = sqlite3.connect(Database.DB_LOCATION)
        self.cur = self.connection.cursor()
        self.create_rooms_table()
        self.create_users_table('students')
        self.create_users_table('educators')


    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.close()
        
    
    def execute_query(self, query: str, params=(), fetchone=False, fetchall=False) -> (Any | list[Any] | None):
        self.cur.execute(query, params)
        self.connection.commit()
        if fetchone:
            return self.cur.fetchone()
        if fetchall:
            return self.cur.fetchall()
    
    
    def create_table(self, table_name: str, columns: Dict[str, str]) -> None:
        column_defs = ", ".join([f"{col} {dtype}" for col, dtype in columns.items()])
        self.execute_query(f"CREATE TABLE IF NOT EXISTS {table_name} ({column_defs})")
        
    
    def create_rooms_table(self) -> None:
        columns = {
            'key_n': 'INTEGER PRIMARY KEY',
            'admin_id': 'INT',
            'title': 'TEXT',
            'pinned_messages': 'TEXT',
            'members': 'TEXT'
        }
        self.create_table('rooms', columns)
    
    
    def create_users_table(self, table_name: str) -> None:
        columns = {
            'key_n': 'INTEGER PRIMARY KEY',
            'user_id': 'INT',
            'full_name': 'TEXT',
            'information': 'TEXT',
            'rooms': 'TEXT'
        }
        self.create_table(table_name, columns)
        
    
    def add_user(self, table_name: str, values: List[Any]) -> None:
        self.execute_query(f"INSERT INTO {table_name} VALUES (NULL, ?, ?, ?, ?)", values)
        
    
    def update_value(self, table_name: str, field_name: str, new_value: str | int, condition_field: str, condition_value: str | int) -> None:
        self.execute_query(f"UPDATE {table_name} SET {field_name} = ? WHERE {condition_field} = ?", (new_value, condition_value))


    def delete_record(self, table_name: str, condition_field: str, condition_value: str | int) -> None:
        self.execute_query(f"DELETE FROM {table_name} WHERE {condition_field} = ?", (condition_value,))
    
    
    def add_rooms(self, values: List[Any]) -> RoomData:
        self.execute_query("INSERT INTO rooms (admin_id, title, pinned_messages, members) VALUES (?, ?, ?, ?)", values)
        last_id = self.cur.lastrowid
        room_info = self.execute_query("SELECT * FROM rooms WHERE key_n = ?", (last_id,), fetchone=True)
        return self.room_data(room_info)

    
    def search_and_check_users(self, user_id: int) -> UserData | None:
        user = self.execute_query("SELECT * FROM students WHERE user_id = ?", (user_id,), fetchone=True)
        role = 'students'
        if not user:
            user = self.execute_query("SELECT * FROM educators WHERE user_id = ?", (user_id,), fetchone=True)
            role = 'educators' if user else None
        return self.user_data(user, role) if user else None
    
    
    def clear_table(self) -> None:
        self.execute_query(f'DELETE FROM rooms')
        self.execute_query(f'DELETE FROM students')
        self.execute_query(f'DELETE FROM educators')
    
    
    def select_rooms_by_admin_id(self, admin_id: int):
        rooms = self.execute_query("SELECT * FROM rooms WHERE admin_id = ?", (admin_id,), fetchall=True)
        return [self.room_data(room) for room in rooms]


    def select_room(self, where: str, value: str | int):
        room = self.execute_query(f"SELECT * FROM rooms WHERE {where} = ?", (value,), fetchone=True)
        return self.room_data(room) if room else None
    
    
    def select_users(self, table_name: str, where: str, value: str | int):
        user = self.execute_query(f"SELECT * FROM {table_name} WHERE {where} = ?", (value,), fetchone=True)
        return self.user_data(user, table_name) if user else None
    
    
    def get_all_contact_info_educator(self):
        self.cur.execute(f"SELECT * FROM educators")
        educators = self.cur.fetchall()
        return educators
    
    
    def deleting_room_from_all_users(self, key_n: int):
        self.cur.execute(f"SELECT * FROM students")
        students = self.cur.fetchall()
        for student in students:
            new_room_list = [x for x in json.loads(student[4]) if x != int(key_n)]
            self.update_value('students', 'rooms', json.dumps(new_room_list), 'user_id', student[1])
        
    
    def room_data(self, room: Dict):
        return RoomData(
            key_n=room[0],
            admin_id=room[1],
            title=room[2],
            pinned_messages=json.loads(room[3]),
            members=json.loads(room[4])
        ) if room else None
    
    
    def user_data(self, user: Dict, role: str):
        return UserData(
            key_n=user[0],
            user_id=user[1],
            full_name=user[2],
            information=user[3],
            rooms=json.loads(user[4]),
            role=role
        ) if user else None