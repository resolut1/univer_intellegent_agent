from . import mangaParser
from . import telegraphAPI
from . import image_slicer
from . import deleteScripts