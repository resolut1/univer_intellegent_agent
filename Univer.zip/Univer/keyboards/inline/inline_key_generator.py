from typing import List, Tuple, Dict

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData


async def inline_key_gen(buttons: List[Dict[str, str | CallbackData]]) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    for button in buttons:
        keyboard.row(
            InlineKeyboardButton(
                text=button['text'],
                callback_data=button['callback_data']
            )
        )
    
    return keyboard