from aiogram.utils.callback_data import CallbackData
from typing import List, Tuple, Dict
from loader import db

cb_room_control = CallbackData("dun_w", "flag", "key_n")


def create_button(text: str, callback_data: str) -> Dict[str, str]:
    return {'text': text, 'callback_data': callback_data}


def get_back_room_button(key_n: int) -> Dict[str, CallbackData]:
    return create_button('◀️ Назад', cb_room_control.new(flag='backToRoomControlMenu', key_n=key_n))


def get_menu_with_back_button(items: List[Dict[str, str | CallbackData]], key_n: int):
    return items + [get_back_room_button(key_n)]


def create_menu(buttons: List[Tuple[str, str | CallbackData]], back_button=None) -> List[Dict[str, str | CallbackData]]:
    menu = [create_button(text, callback_data) for text, callback_data in buttons]
    if back_button:
        menu.append(back_button)
    return menu


def get_room_management(key_n: int) -> List[Dict[str, CallbackData]]:
    return get_menu_with_back_button([
        create_button('✏️ Изменить название', cb_room_control.new(flag='changeTitle', key_n=key_n)),
        create_button('🚮 Удалить участников', cb_room_control.new(flag='deleteMembers', key_n=key_n)),
        create_button('🗑 Удалить комнату', cb_room_control.new(flag='deleteRoom', key_n=key_n)),
    ], key_n)


def get_room_message_management(key_n: int) -> List[Dict[str, str | CallbackData]]:
    return get_menu_with_back_button([
        create_button('🧹 Очистить закрепленные сообщения', cb_room_control.new(flag='clearPinnedMessages', key_n=key_n)),
        create_button('📍 Закрепить новое сообщение', cb_room_control.new(flag='pinnedNewMessage', key_n=key_n)),
    ], key_n)


def get_control_menu(role: str) -> List[Dict[str, str]]:
    common_buttons = [
        {'text': '🗑 Удалить аккаунт', 'callback_data': 'deleteAccount'},
        {'text': '✏️ Изменить ФИО', 'callback_data': 'changeFullName'},
    ]
    
    role_specific_buttons = {
        'students': [
            {'text': '✏️ Изменить группу', 'callback_data': 'changeGroup'},
            back_button_main_student_menu
        ],
        'educators': [
            {'text': '☎️ Указать контактную информацию', 'callback_data': 'fillContactInfo'},
            back_button_main_edu_menu
        ],
    }
    
    return common_buttons + role_specific_buttons.get(role, [])


def get_my_room_list(user_id: int) -> List[Dict[str, CallbackData]]:
    my_rooms = db.select_rooms_by_admin_id(user_id)
    return [{
        'text': f'🏛 {room.title} | 👥 {len(room.members)}',
        'callback_data': cb_room_control.new(flag=room.title, key_n=room.key_n)
    } for room in my_rooms]


def get_room_control_menu(key_n: int) -> List[Dict[str, str | CallbackData]]:
    return create_menu([
        ('🧩 Управление комнатой', cb_room_control.new(flag='editRoom', key_n=key_n)),
        ('🐣 Пригласить студентов', cb_room_control.new(flag='inviteStudentRoom', key_n=key_n)),
        ('✉️ Работа с сообщениями', cb_room_control.new(flag='messageRoomMenu', key_n=key_n)),
        ('◀️ Отменить', "backToMainEduMenu")
    ])


register_keyboard = [create_button('👤 Я студент [Регистрация]', "regStudent")]
back_button_main_edu_menu = create_button('◀️ Отменить', "backToMainEduMenu")
back_button_main_student_menu = create_button('◀️ Отменить', "backToMainStudentMenu")
back_button_main_menu = create_button('◀️ Отменить процесс', "backToMainMenu")
back_button_skip_contact = [
    create_button('◀️ Отменить регистрацию', "backToMainMenu"),
    create_button('🕓 Пока не указывать', "skipContactInfo")
]

student_menu = create_menu([
    ('☎️ Контактная информация преподавателей', "contactInformEducators"),
    ('📍 Все закрепленные сообщения', "viewLastFixedMessage"),
    ('👤 Управление аккаунтом', "editAccount"),
    ('🏛 Выйти из комнаты', "exitRoomsStudent"),
])

educator_menu = create_menu([
    ('🏛 Список всех курируемых комнат', "listRoomsEducator"),
    ('🐣 Пригласить студента в бота', "getInviteStudentLink"),
    ('👤 Управление аккаунтом', "editAccount"),
    ('🛠 Создать новую комнату', "createNewRoom"),
])

admin_menu_keyboard = create_menu([
    ('🎓 Пригласить преподавателя', 'getInviteLinkEducator'),
    ('👤 Пригласить студента', 'getInviteLinkStudent'),
])